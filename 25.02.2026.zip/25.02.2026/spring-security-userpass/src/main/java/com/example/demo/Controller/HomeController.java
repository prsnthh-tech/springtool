package com.example.demo.Controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HomeController {

    @GetMapping("/")
    public String welcome() {
        return "Welcome to the Spring Security App!";
    }

    @GetMapping("/home")
    public String home() {
        return "You are logged in successfully!";
    }
}