package com.example.demo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Repos.MyRepo;
import com.example.demo.modelorentity.Employee;

@Service
public class Myservice {

    @Autowired
    private MyRepo repo;

    // GET all
    public List<Employee> getAllEmployee() {
        return repo.findAll();
    }

    // GET by ID
    public Employee getEmployeebyID(int id) {
        return repo.findById(id)
                .orElseThrow(() -> new RuntimeException("Employee not found with id " + id));
    }

    // POST
    public String addEmployee(Employee employee) {
        repo.save(employee);
        return "Employee Added Successfully";
    }

    // PUT
    public String updateEmployee(int id, Employee updateEmployee) {
        Employee emp = repo.findById(id)
                .orElseThrow(() -> new RuntimeException("Employee not found with id " + id));

        emp.setName(updateEmployee.getName());
        emp.setAge(updateEmployee.getAge());
        emp.setSalary(updateEmployee.getSalary());
        emp.setDesig(updateEmployee.getDesig());

        repo.save(emp);
        return "Employee Updated Successfully";
    }

    // DELETE by ID
    public String deleteEmployee(int id) {
        if (repo.existsById(id)) {
            repo.deleteById(id);
            return "Employee Deleted Successfully";
        } else {
            return "Employee not found with ID " + id;
        }
    }

    // DELETE all
    public String deleteAllEmployee() {
        repo.deleteAll();
        return "All Employees Deleted Successfully";
    }
}