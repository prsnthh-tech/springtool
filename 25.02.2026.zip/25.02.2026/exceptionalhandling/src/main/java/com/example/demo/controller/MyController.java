package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.modelorentity.Employee;
import com.example.demo.services.Myservice;

@RestController
@RequestMapping("/employee")
public class MyController {

    @Autowired
    private Myservice service;

    // GET all employees
    @GetMapping
    public List<Employee> getAllEmployee() {
        return service.getAllEmployee();
    }

    // GET by ID
    @GetMapping("/{id}")
    public Employee getEmployeeById(@PathVariable int id) {
        return service.getEmployeebyID(id);
    }

    // POST
    @PostMapping
    public String addEmployee(@RequestBody Employee employee) {
        return service.addEmployee(employee);
    }

    // PUT
    @PutMapping("/{id}")
    public String updateEmployee(@PathVariable int id,
                                 @RequestBody Employee updateEmployee) {
        return service.updateEmployee(id, updateEmployee);
    }

    // DELETE by ID
    @DeleteMapping("/{id}")
    public String deleteEmployee(@PathVariable int id) {
        return service.deleteEmployee(id);
    }

    // DELETE all
    @DeleteMapping
    public String deleteAllEmployee() {
        return service.deleteAllEmployee();
    }
}