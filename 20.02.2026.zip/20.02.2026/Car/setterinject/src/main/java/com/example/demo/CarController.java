package com.example.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CarController {
	private Car tata;
	public CarController(Car Lambhorgini)
	{
		this.tata=Lambhorgini;
	}
	@GetMapping("/drive")
	public String driveCar()
	{
		return tata.drive();
	}

}
