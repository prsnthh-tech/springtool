package springstarter;

public class springstart {

}
