package com.example.demo;

public class Childclass {

    protected String username;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String commonMessage() {
        return "This is common logic from User class";
    }
}