package com.example.demo;

import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/admin1")
public class AdminController {

    @GetMapping
    public String testAdmin() {

        Admin admin = new Admin();
        admin.setUsername("Prashanth");
        admin.setRole("Manager");

        return admin.commonMessage() + 
               " | Username: " + admin.getUsername() + 
               " | Role: " + admin.getRole();
    }
}