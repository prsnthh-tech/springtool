package com.example.demo;

public class Admin extends Childclass {

    private String role;

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String adminMessage() {
        return "This is Admin specific logic";
    }
}