package com.example.demo;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HeusenLoginController {

    // Show Login Page
    @GetMapping("/login")
    public String loginPage() {
        return "login";
    }

    // Process Login
    @PostMapping("/login")
    public String validateLogin(
            @RequestParam String username,
            @RequestParam String password,
            Model model) {

        // Real-time example (hardcoded for learning)
        if (username.equals("prasanth") && password.equals("prasanth")) {
            model.addAttribute("username", username);
            return "welcome";
        } else {
            model.addAttribute("error", "Invalid credentials");
            return "login";
        }
    }
}