package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Exception1Application {

	public static void main(String[] args) {
		SpringApplication.run(Exception1Application.class, args);
		System.out.println("Spring is winner of sprinting");
	}

}
