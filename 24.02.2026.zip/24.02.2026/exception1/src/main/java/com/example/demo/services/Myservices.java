package com.example.demo.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Repos.MyRepo;
import com.example.demo.modelorentity.Employee;

@Service
public class Myservices {
	@Autowired
	private MyRepo repo;
	
	public List<Employee> getAllEmployee()
	{
		return repo.findAll();
	}
	public String addEmployee(Employee employee)
	{
		repo.save(employee);
		return "Employee added successfully";
	}
	public String UpdateEmployee(int id, Employee updateEmployee)
	{
		Optional<Employee> existingemp=repo.findAll(id);
		if (existingemp.isPresent())
		{
			Employee emp = existingemp.get();
			emp.setName(updateEmployee.getName());
			emp.setAge(updateEmployee.getAge());
			emp.setSalary(updateEmployee.getSalary());
			emp.setDesignation(updateEmployee.getDesignation());
			repo.save(emp);
			return "employeeUpdated Successfully";
			
		}else
		
		return "Employee updated successfully";

	}
	public String deleteEmployee(int id)
	{
		if (repo.existsById(id))
		{
			repo.deleteById(id);
			return "Employee deleted successfully";
				
		}else
		{
			return "Employee Not found with id" +id;
		}
	}
}
