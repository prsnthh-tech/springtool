package com.example.demo;


import org.springframework.data.jpa.repository.JpaRepository;

public interface Student02Repository extends JpaRepository<Student02, Integer> {
}