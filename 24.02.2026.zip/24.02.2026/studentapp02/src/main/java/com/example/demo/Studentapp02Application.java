package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Studentapp02Application {

	public static void main(String[] args) {
		SpringApplication.run(Studentapp02Application.class, args);
	}

}
