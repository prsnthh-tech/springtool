package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/students")
public class Student02Controller {

    @Autowired
    private Student02Repository repo;

    // POST – Create Student
    @PostMapping
    public ResponseEntity<Student02> addStudent(@RequestBody Student02 student) {
        return new ResponseEntity<>(repo.save(student), HttpStatus.CREATED);
    }

    // GET – Get All Students
    @GetMapping
    public ResponseEntity<List<Student02>> getAllStudents() {
        return new ResponseEntity<>(repo.findAll(), HttpStatus.OK);
    }

    // PUT – Update Student
    @PutMapping("/{id}")
    public ResponseEntity<Student02> updateStudent(@PathVariable int id,
                                                 @RequestBody Student02 studentDetails) {

        Student02 student = repo.findById(id).orElse(null);

        if (student == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        student.setName(studentDetails.getName());
        student.setCourse(studentDetails.getCourse());

        Student02 updatedStudent = repo.save(student);
        return new ResponseEntity<>(updatedStudent, HttpStatus.OK);
    }

    // DELETE – Delete Student
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteStudent(@PathVariable int id) {
        repo.deleteById(id);
        return new ResponseEntity<>("Deleted successfully", HttpStatus.OK);
    }
}