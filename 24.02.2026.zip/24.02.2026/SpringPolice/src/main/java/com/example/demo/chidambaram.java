package com.example.demo;

public class chidambaram {
	
	public static void main (String []args) {
		try
		{
		System.out.println("asfsafsf");
		System.out.println("asdfsaf s");
		System.out.println(10/0);
		System.out.println("asfsfsf");
		System.out.println("asfsfsf");
		} catch (Exception e)
		{
			System.out.println("Hell from catch");
		}
		System.out.println("asfsfsf");
	}

}
