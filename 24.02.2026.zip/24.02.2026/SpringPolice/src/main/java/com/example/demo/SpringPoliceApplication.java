package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringPoliceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringPoliceApplication.class, args);
	}

}
