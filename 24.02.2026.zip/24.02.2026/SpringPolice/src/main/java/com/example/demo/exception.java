package com.example.demo;

public class exception
{
	
	public static void main (String []args)
{
		
		try
		{
			int a[]= { 10,20,30};
		System.out.println(a[0]);
		System.out.println(a[1]);
		System.out.println(a[2]);
		// System.out.println(a[3]);
		System.out.println(10/0);
		System.out.println("asfsfsf");
		System.out.println("asfsfsf");
		} catch (ArrayIndexOutOfBoundsException e)
			{
				System.out.println("hell from catch" +e);
			}catch(ArithmeticException e1)
		{
				System.out.println("Hell from catch"+e1);
		} catch(Exception e2)
		{
			System.out.println("hell from catch"+e2);
		}
		System.out.println("asfsfsf");
		}
	
		
	

}

