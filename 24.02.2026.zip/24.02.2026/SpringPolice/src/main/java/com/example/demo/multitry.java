package com.example.demo;

public class multitry {
	
	public static void main (String []args)
{
		
		try
		{  System.out.println(10/0);
		}catch (Exception e)
		{
			System.out.println("Hell from" +e );
	
		}
		try
		{
			int a[]= { 10,20,30};
		System.out.println(a[0]);
		System.out.println(a[1]);
		System.out.println(a[2]);
		System.out.println(a[3]);
		
		System.out.println("asfsfsf");
		System.out.println("asfsfsf");
		} catch (ArrayIndexOutOfBoundsException e)
			{
				System.out.println("hell from catch" +e);
			}catch(ArithmeticException e)
		{
				System.out.println("Hell from catch");
		}
		System.out.println("asfsfsf");
		}
	
		
	

}

