package com.example.demo;

public class excit {



	public static void main (String []args)
{
		
		
		try
		{
			int a[]= { 10,20,30};
		System.out.println(a[0]);
		System.out.println(a[1]);
		System.out.println(a[2]);
	//	System.out.println(a[3]);
		try
		{  System.out.println(10/0);
		}catch (Exception e)
		{
			System.out.println("Hell from" +e );
	
		}
		
		System.out.println("asfsfsf");
		System.out.println("asfsfsf");
		System.exit(0);
		} catch (ArrayIndexOutOfBoundsException e)
			{
				System.out.println("hell from catch" +e);
			}catch(ArithmeticException e)
		{
				System.out.println("Hell from catch");
		}
		
		finally 
			{
				System.out.println("Its the end");
			}
		}
		}
	
		
	





