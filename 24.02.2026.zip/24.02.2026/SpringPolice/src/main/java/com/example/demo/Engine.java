package com.example.demo;

import org.springframework.stereotype.Component;

@Component

public class Engine {
public String Engine()
{
	return " Engine started";
}

}
